
import React, { useState, useCallback } from 'react';
import { BatchResult, SEOAnalysis } from './types';
import { analyzeKeyword } from './services/gemini';
import KeywordInput from './components/KeywordInput';
import ResultCard from './components/ResultCard';

const App: React.FC = () => {
  const [results, setResults] = useState<BatchResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleAnalyze = useCallback(async (keywords: string[]) => {
    setIsProcessing(true);
    
    // Initialize results with loading state
    const initialResults: BatchResult[] = keywords.map(kw => ({
      keyword: kw,
      loading: true
    }));
    setResults(initialResults);

    // Process one by one to avoid rate limiting and allow UI updates
    for (let i = 0; i < keywords.length; i++) {
      const kw = keywords[i];
      try {
        const analysis = await analyzeKeyword(kw);
        setResults(prev => prev.map((r, idx) => 
          idx === i ? { ...r, analysis, loading: false } : r
        ));
      } catch (err: any) {
        setResults(prev => prev.map((r, idx) => 
          idx === i ? { ...r, error: err.message, loading: false } : r
        ));
      }
    }
    
    setIsProcessing(false);
  }, []);

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="bg-slate-900 text-white py-12 px-6 mb-12 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 16h2v2h-2zm0-6h2v4h-2z" />
          </svg>
        </div>
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-blue-600 p-1.5 rounded-lg">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <span className="text-blue-400 font-bold tracking-tighter text-sm uppercase">Version 2.0 Optimized</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">2026 B2B SEO & GEO Content Architect</h1>
          <p className="text-slate-400 max-w-2xl text-lg leading-relaxed">
            Generate high-E-E-A-T industrial content structures that dominate 2026 search engines (SGE, Perplexity) 
            while converting human procurement decision-makers.
          </p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <aside className="lg:col-span-1">
            <div className="sticky top-8">
              <KeywordInput onAnalyze={handleAnalyze} isLoading={isProcessing} />
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-800 mb-4 uppercase text-xs tracking-widest">Architect Logic</h3>
                <ul className="space-y-3 text-sm text-slate-500">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 font-bold">01</span>
                    <span>Intent Identification (Info/Comm/Trans)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 font-bold">02</span>
                    <span>H1 Click Magnet Optimization</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 font-bold">03</span>
                    <span>PAA (People Also Ask) Integration</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 font-bold">04</span>
                    <span>GEO/AI SGE Citation Strategy</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 font-bold">05</span>
                    <span>Industrial E-E-A-T Backing</span>
                  </li>
                </ul>
              </div>
            </div>
          </aside>

          <section className="lg:col-span-3">
            {results.length === 0 && !isProcessing && (
              <div className="h-64 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center text-slate-400">
                <svg className="w-12 h-12 mb-4 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
                <p>Waiting for keywords to start architecture planning...</p>
              </div>
            )}

            <div className="space-y-8">
              {results.map((res, i) => (
                <div key={i}>
                  {res.loading ? (
                    <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm animate-pulse">
                      <div className="flex justify-between mb-8">
                        <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                        <div className="h-8 bg-slate-100 rounded w-24"></div>
                      </div>
                      <div className="space-y-4">
                        <div className="h-4 bg-slate-100 rounded w-full"></div>
                        <div className="h-4 bg-slate-100 rounded w-5/6"></div>
                        <div className="h-4 bg-slate-100 rounded w-4/6"></div>
                      </div>
                    </div>
                  ) : res.error ? (
                    <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-red-800">
                      <div className="flex items-center gap-2 mb-2 font-bold">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Analysis Failed: {res.keyword}
                      </div>
                      <p className="text-sm opacity-80">{res.error}</p>
                    </div>
                  ) : res.analysis ? (
                    <ResultCard analysis={res.analysis} />
                  ) : null}
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>

      {/* Footer Info */}
      <footer className="mt-20 border-t border-slate-200 py-12 bg-white">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <p className="text-slate-500 text-sm">
            © 2026 B2B SEO & GEO Architect V2.0 • Industrial Manufacturing Optimized
          </p>
          <p className="text-slate-400 text-xs mt-2 uppercase tracking-widest">
            Powered by Gemini-3 High Reasoning Model
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
