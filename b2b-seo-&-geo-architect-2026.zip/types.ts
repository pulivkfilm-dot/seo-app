
export interface H1Title {
  title: string;
  strategy: string;
}

export interface Section {
  h2: string;
  h3: string[];
  isPAA: boolean;
  description: string;
}

export interface SEOAnalysis {
  keyword: string;
  userIntent: 'Informational' | 'Commercial Investigation' | 'Transactional';
  optimizedH1s: H1Title[];
  seoLogicAndLsi: string;
  contentFramework: Section[];
  geoAiOptimization: string;
}

export interface BatchResult {
  keyword: string;
  analysis?: SEOAnalysis;
  error?: string;
  loading: boolean;
}
