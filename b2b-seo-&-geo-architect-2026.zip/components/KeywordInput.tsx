
import React from 'react';

interface KeywordInputProps {
  onAnalyze: (keywords: string[]) => void;
  isLoading: boolean;
}

const KeywordInput: React.FC<KeywordInputProps> = ({ onAnalyze, isLoading }) => {
  const [text, setText] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const keywords = text.split('\n').map(k => k.trim()).filter(k => k.length > 0);
    if (keywords.length > 0) {
      onAnalyze(keywords);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-8">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="keywords" className="block text-sm font-semibold text-slate-700 mb-2 uppercase tracking-wider">
            Target Keywords (One per line)
          </label>
          <textarea
            id="keywords"
            rows={5}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all font-mono text-sm"
            placeholder="e.g. 5-Axis Water Jet Machine&#10;Industrial PLC Controllers&#10;OEM Hydraulic Pump Manufacturer"
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={isLoading}
          />
        </div>
        <button
          type="submit"
          disabled={isLoading || !text.trim()}
          className={`w-full py-3 px-6 rounded-lg font-bold text-white transition-all flex items-center justify-center gap-2 ${
            isLoading || !text.trim()
              ? 'bg-slate-300 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 active:scale-[0.98] shadow-lg shadow-blue-200'
          }`}
        >
          {isLoading ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              Architecting Strategy...
            </>
          ) : (
            <>
              Generate SEO Architecture
              <svg className="w-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default KeywordInput;
