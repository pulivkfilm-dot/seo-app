
import React from 'react';
import { SEOAnalysis } from '../types';

interface ResultCardProps {
  analysis: SEOAnalysis;
}

const ResultCard: React.FC<ResultCardProps> = ({ analysis }) => {
  const intentColors = {
    Informational: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    'Commercial Investigation': 'bg-blue-100 text-blue-800 border-blue-200',
    Transactional: 'bg-amber-100 text-amber-800 border-amber-200'
  };

  const copyToClipboard = () => {
    // Basic Markdown generator for the table view requested
    const markdown = `| Column | Content Requirement |
| :--- | :--- |
| **User Intent** | ${analysis.userIntent} |
| **Optimized H1 Titles** | ${analysis.optimizedH1s.map((h1, i) => `${i+1}. ${h1.title} (策略: ${h1.strategy})`).join('<br>')} |
| **SEO Logic & LSI** | ${analysis.seoLogicAndLsi} |
| **Content Framework** | ${analysis.contentFramework.map(f => `${f.h2}${f.isPAA ? ' (PAA)' : ''}\\n${f.h3.map(sub => `  - ${sub}`).join('\\n')}`).join('\\n\\n')} |
| **GEO/AI Optimization** | ${analysis.geoAiOptimization} |`;
    
    navigator.clipboard.writeText(markdown);
    alert('Copied as Markdown Table!');
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden mb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="p-6 border-b border-slate-100 bg-slate-50 flex flex-wrap justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold text-slate-900">{analysis.keyword}</h2>
          <span className={`px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider ${intentColors[analysis.userIntent]}`}>
            {analysis.userIntent}
          </span>
        </div>
        <button 
          onClick={copyToClipboard}
          className="text-sm font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 bg-white border border-blue-200 px-3 py-1.5 rounded-lg transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
          </svg>
          Copy Markdown Table
        </button>
      </div>

      <div className="p-0 overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest w-48 border-b">Column</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest border-b">Architecture Data</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr>
              <td className="px-6 py-6 align-top font-bold text-slate-700 bg-slate-50/20">Optimized H1 Titles</td>
              <td className="px-6 py-6">
                <ul className="space-y-4">
                  {analysis.optimizedH1s.map((h1, i) => (
                    <li key={i} className="group">
                      <div className="text-lg font-medium text-slate-900 group-hover:text-blue-700 transition-colors">
                        {h1.title}
                      </div>
                      <div className="text-xs text-slate-400 mt-1 italic">
                        Strategy: <span className="text-slate-600 font-semibold">{h1.strategy}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-6 align-top font-bold text-slate-700 bg-slate-50/20">SEO Logic & LSI</td>
              <td className="px-6 py-6 text-slate-600 leading-relaxed whitespace-pre-wrap">
                {analysis.seoLogicAndLsi}
              </td>
            </tr>
            <tr>
              <td className="px-6 py-6 align-top font-bold text-slate-700 bg-slate-50/20">Content Framework</td>
              <td className="px-6 py-6">
                <div className="space-y-6">
                  {analysis.contentFramework.map((section, idx) => (
                    <div key={idx} className="bg-slate-50/50 border border-slate-100 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded text-[10px] font-bold">H2</span>
                        <h3 className="font-bold text-slate-800">{section.h2}</h3>
                        {section.isPAA && (
                          <span className="bg-blue-600 text-white px-2 py-0.5 rounded text-[10px] font-bold">PAA</span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mb-3 italic">{section.description}</p>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
                        {section.h3.map((sub, sIdx) => (
                          <li key={sIdx} className="flex items-center gap-2 text-sm text-slate-600">
                            <span className="w-1 h-1 bg-slate-400 rounded-full"></span>
                            <span className="font-semibold text-slate-400 mr-1 italic">H3</span>
                            {sub}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-6 align-top font-bold text-slate-700 bg-slate-50/20">GEO/AI Optimization</td>
              <td className="px-6 py-6">
                <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-lg text-indigo-900 text-sm leading-relaxed">
                  <div className="font-bold mb-2 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1a1 1 0 112 0v1a1 1 0 11-2 0zM13.536 14.243a1 1 0 011.414 1.414l-.707.707a1 1 0 01-1.414-1.414l.707-.707zM16 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1z" />
                    </svg>
                    GEO Strategy for Gemini/SGE
                  </div>
                  {analysis.geoAiOptimization}
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ResultCard;
