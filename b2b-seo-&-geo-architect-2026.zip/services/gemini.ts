
import { GoogleGenAI, Type } from "@google/genai";
import { SEOAnalysis } from "../types";

const SYSTEM_INSTRUCTION = `
You are a 2026 B2B SEO & GEO Content Architect (v2.0 Optimized). 
Your expertise is in industrial and manufacturing B2B marketing.
Your core goal is to balance technical E-E-A-T with User Intent, creating content that AI search engines (SGE, Perplexity) love and human decision-makers click.

EXECUTION LOGIC:
1. Identify User Intent: Informational, Commercial Investigation, or Transactional.
2. Create 5-6 H1 Titles using the "Perfect Click" strategy:
   - Use LSI & Variants.
   - Front-load core keywords.
   - Use Numbers/Lists.
   - Benefit-Driven (Pain point -> Solution).
   - Risk Reversal (Avoid, Stop, Zero-Defect).
   - NLP & Voice Search friendly.
   - Simplify Jargon.
   - Use CTR Magnets (2026 Guide, ROI Calculator).
   - Geo-Specific (Global Shipping, EU Standards).
   - Action-Oriented CTA.
3. SERP Gap Analysis: Emphasize factory-depth info (Traceability, QC, Capacity).
4. Integrate 3-5 PAA (People Also Ask) questions as H2/H3.
5. Structured Outline: GEO Summary -> Pain Points -> Tech Specs -> Trust -> CTA.

OUTPUT REQUIREMENT:
You must return a valid JSON object matching the provided schema. No markdown outside the JSON.
`;

export async function analyzeKeyword(keyword: string): Promise<SEOAnalysis> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following B2B keyword: "${keyword}"`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          keyword: { type: Type.STRING },
          userIntent: { type: Type.STRING },
          optimizedH1s: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                strategy: { type: Type.STRING }
              },
              required: ["title", "strategy"]
            }
          },
          seoLogicAndLsi: { type: Type.STRING },
          contentFramework: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                h2: { type: Type.STRING },
                h3: { type: Type.ARRAY, items: { type: Type.STRING } },
                isPAA: { type: Type.BOOLEAN },
                description: { type: Type.STRING }
              },
              required: ["h2", "h3", "isPAA", "description"]
            }
          },
          geoAiOptimization: { type: Type.STRING }
        },
        required: ["keyword", "userIntent", "optimizedH1s", "seoLogicAndLsi", "contentFramework", "geoAiOptimization"]
      }
    }
  });

  try {
    const text = response.text;
    return JSON.parse(text);
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Invalid response format from AI");
  }
}
